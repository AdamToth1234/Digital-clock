setInterval(hourGet, 1000)
setInterval(minuteGet, 1000)
setInterval(secondGet, 1000)


const time = document.querySelector(".time")
const hours = Array.from(time.children)[0]
const minutes = Array.from(time.children)[1]
const seconds = Array.from(time.children)[2]

const date = document.querySelector(".date")
const days = Array.from(date.children)[0]
const years = Array.from(date.children)[2]
const months = Array.from(date.children)[1]


function hourGet(){
    const date = new Date()
    let hour = date.getHours()
    if (hour < 10){
        hour = `0${date.getHours()}:`
    } else{
        hour = `${date.getHours()}:`
    }
    hours.innerHTML = ""
    hours.innerHTML = hour
}

function minuteGet(){
    const date = new Date()
    let minute = date.getMinutes()
    if (minute < 10){
        minute = `0${date.getMinutes()}:`
    } else{
        minute = `${date.getMinutes()}:`
    }
    minutes.innerHTML = ""
    minutes.innerHTML = minute
}

function secondGet(){
    const date = new Date()
    let second = date.getSeconds()
    if (second < 10){
        second = `0${date.getSeconds()}`
    }
    seconds.innerHTML = ""
    seconds.innerHTML = second
}

function dayGet(){
    const date = new Date()
    let day = date.getDate()
    console.log(day);
}

hourGet()
minuteGet()
secondGet()
dayGet()
